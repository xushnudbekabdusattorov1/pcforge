// src/App.jsx
import React, { useState } from 'react';
import Loader from './components/Loader';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Marquee from './components/Marquee';
import Components from './components/Components';
import Builds from './components/Builds';
import Services from './components/Services';
import WhyUs from './components/WhyUs';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import useReveal from './hooks/useReveal';
import useFX from './hooks/useFX';

const App = () => {
  useReveal();
  useFX();
  const [selectedBuild, setSelectedBuild] = useState('');

  return (
    <>
      <Loader />
      <div className="scroll-progress" />
      <div className="cursor-glow" />
      <Navbar />
      <Hero />
      <Marquee />
      <Components />
      <Builds setSelectedBuild={setSelectedBuild} />
      <Services />
      <WhyUs />
      <Testimonials />
      <Contact selectedBuild={selectedBuild} />
      <Footer />
    </>
  );
};

export default App;
