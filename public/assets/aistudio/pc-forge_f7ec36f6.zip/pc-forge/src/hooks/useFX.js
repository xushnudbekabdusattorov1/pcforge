// src/hooks/useFX.js - global motion effects (no libraries)
import { useEffect } from 'react';

export default function useFX() {
  useEffect(() => {
    const root = document.documentElement;
    const fine = window.matchMedia('(pointer: fine)').matches;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const cleanups = [];
    const on = (t, ev, fn, o) => {
      t.addEventListener(ev, fn, o);
      cleanups.push(() => t.removeEventListener(ev, fn, o));
    };

    // scroll progress bar + parallax variable
    const bar = document.querySelector('.scroll-progress');
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        const y = window.scrollY;
        const max = root.scrollHeight - window.innerHeight;
        if (bar) bar.style.transform = `scaleX(${max > 0 ? y / max : 0})`;
        root.style.setProperty('--scroll', Math.min(y, 900));
        ticking = false;
      });
    };
    onScroll();
    on(window, 'scroll', onScroll, { passive: true });

    if (!reduce && fine) {
      // cursor glow with smooth trailing
      const glow = document.querySelector('.cursor-glow');
      let tx = window.innerWidth / 2, ty = window.innerHeight / 2, x = tx, y = ty, raf;
      on(window, 'pointermove', (e) => {
        tx = e.clientX;
        ty = e.clientY;
        if (glow) glow.classList.add('on');
      });
      const loop = () => {
        x += (tx - x) * 0.12;
        y += (ty - y) * 0.12;
        if (glow) glow.style.transform = `translate3d(${x}px, ${y}px, 0)`;
        raf = requestAnimationFrame(loop);
      };
      loop();
      cleanups.push(() => cancelAnimationFrame(raf));

      // cards: cursor spotlight + 3D tilt
      document.querySelectorAll('.card').forEach((card) => {
        const tilt = card.hasAttribute('data-tilt');
        on(card, 'pointermove', (e) => {
          const r = card.getBoundingClientRect();
          const px = e.clientX - r.left;
          const py = e.clientY - r.top;
          card.style.setProperty('--sx', `${px}px`);
          card.style.setProperty('--sy', `${py}px`);
          if (tilt) {
            card.style.transform = `perspective(900px) rotateX(${(py / r.height - 0.5) * -10}deg) rotateY(${(px / r.width - 0.5) * 10}deg) translateY(-6px)`;
          }
        });
        on(card, 'pointerleave', () => {
          card.style.transform = '';
        });
      });

      // magnetic buttons
      document.querySelectorAll('[data-magnetic]').forEach((el) => {
        on(el, 'pointermove', (e) => {
          const r = el.getBoundingClientRect();
          el.style.translate = `${(e.clientX - (r.left + r.width / 2)) * 0.3}px ${(e.clientY - (r.top + r.height / 2)) * 0.4}px`;
        });
        on(el, 'pointerleave', () => {
          el.style.translate = '';
        });
      });
    }

    // text decode / scramble effect
    if (!reduce) {
      const glyphs = '01<>/\\_[]{}#$%&*';
      document.querySelectorAll('[data-scramble]').forEach((el) => {
        const final = el.textContent;
        let timer;
        const start = setTimeout(() => {
          let frame = 0;
          const total = 28;
          timer = setInterval(() => {
            frame += 1;
            el.textContent = final
              .split('')
              .map((c, i) => (c === ' ' || i < (frame / total) * final.length ? c : glyphs[Math.floor(Math.random() * glyphs.length)]))
              .join('');
            if (frame >= total) {
              clearInterval(timer);
              el.textContent = final;
            }
          }, 40);
        }, 1650);
        cleanups.push(() => {
          clearTimeout(start);
          clearInterval(timer);
          el.textContent = final;
        });
      });
    }

    return () => cleanups.forEach((fn) => fn());
  }, []);
}
