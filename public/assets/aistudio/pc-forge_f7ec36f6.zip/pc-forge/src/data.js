// src/data.js
export const componentsData = [
  { id: 1, icon: '🧠', name: 'CPUs', desc: 'Intel Core and AMD Ryzen processors for every workload.', price: 199 },
  { id: 2, icon: '🎮', name: 'GPUs', desc: 'NVIDIA GeForce and AMD Radeon cards for ray-traced gaming.', price: 329 },
  { id: 3, icon: '🔌', name: 'Motherboards', desc: 'AM5 and LGA1700 boards with PCIe 5.0 and WiFi 6E.', price: 119 },
  { id: 4, icon: '⚡', name: 'RAM', desc: 'DDR5 memory kits up to 7200 MT/s with RGB options.', price: 49 },
  { id: 5, icon: '💾', name: 'SSDs', desc: 'NVMe Gen4 and Gen5 drives with blazing read speeds.', price: 59 },
  { id: 6, icon: '🔋', name: 'Power Supplies', desc: '80+ Gold modular PSUs from 650W to 1200W.', price: 69 },
  { id: 7, icon: '🖥️', name: 'Cases', desc: 'Airflow-focused towers with tempered glass panels.', price: 79 },
];

export const buildsData = [
  { id: 1, icon: '🚀', name: 'Starter Gamer', price: 899, specs: ['Ryzen 5 7600', 'RTX 4060', '16GB DDR5', '1TB NVMe'] },
  { id: 2, icon: '🔥', name: 'Pro Streamer', price: 1799, popular: true, specs: ['Core i7-14700K', 'RTX 4070 Super', '32GB DDR5', '2TB NVMe'] },
  { id: 3, icon: '👑', name: 'Ultimate Beast', price: 3499, specs: ['Ryzen 9 7950X3D', 'RTX 4090', '64GB DDR5', '4TB NVMe'] },
];

export const servicesData = [
  { id: 1, icon: '🔧', name: 'Custom PC Building', desc: 'Your dream rig, assembled and stress-tested by experts.', points: ['Hand-picked compatible parts', 'Cable management and RGB setup', '48-hour burn-in testing'], price: 99 },
  { id: 2, icon: '⬆️', name: 'PC Upgrades', desc: 'Give your current PC a serious performance boost.', points: ['GPU, RAM and SSD upgrades', 'Free compatibility check', 'Old parts recycling'], price: 49 },
  { id: 3, icon: '🛟', name: 'Technical Support', desc: 'Fast help whenever your system needs attention.', points: ['Remote and in-store diagnostics', 'Driver and OS optimization', 'Priority response for owners'], price: 29 },
];

export const whyUsData = [
  { id: 1, icon: '💎', title: 'Premium Parts', text: 'Only top-tier components from trusted brands.' },
  { id: 2, icon: '🛠️', title: 'Expert Assembly', text: 'Certified engineers build and test every PC.' },
  { id: 3, icon: '🛡️', title: '3-Year Warranty', text: 'Full parts and labor coverage for three years.' },
  { id: 4, icon: '💬', title: '24/7 Support', text: 'Real people ready to help any time of day.' },
];

export const testimonialsData = [
  { id: 1, name: 'Alex M.', role: 'Streamer', quote: 'My Pro Streamer build runs OBS and games at 1440p without a single dropped frame.', rating: 5 },
  { id: 2, name: 'Sara K.', role: '3D Artist', quote: 'Renders that took an hour now finish in minutes. The cable management is a work of art.', rating: 5 },
  { id: 3, name: 'Daniel R.', role: 'Esports Player', quote: 'Fast delivery, quiet and cool under load. Support answered at 2 a.m. when I had a question.', rating: 5 },
];

export const contactData = {
  email: 'support@pcforge.com',
  phone: '+1 (555) 123-4567',
  address: '123 Main St, Anytown, USA',
  hours: 'Mon-Fri 9am-5pm',
};

export const brands = ['NVIDIA', 'AMD', 'INTEL', 'ASUS ROG', 'MSI', 'CORSAIR', 'SAMSUNG', 'NOCTUA', 'KINGSTON', 'GIGABYTE'];
