// src/components/Hero.jsx
import React from 'react';
import ParticleField from './ParticleField';
import Count from './Count';

const Words = ({ text, grad = false, start = 0 }) =>
  text.split(' ').map((w, i) => (
    <React.Fragment key={w + i}>
      <span className="hw">
        <span className={`hwi${grad ? ' grad-text' : ''}`} style={{ '--i': start + i }}>{w}</span>
      </span>{' '}
    </React.Fragment>
  ));

const Hero = () => (
  <section id="home" className="hero">
    <ParticleField />
    <div className="rings" aria-hidden="true">
      <i />
      <i />
      <i />
    </div>
    <div className="container hero-content">
      <span className="hero-badge fadeup" data-scramble>Custom PC Builds</span>
      <h1 className="hero-title" aria-label="Build the PC of Your Dreams">
        <span className="hl" aria-hidden="true"><Words text="Build the PC of" /></span>
        <span className="hl" aria-hidden="true"><Words text="Your Dreams" grad start={4} /></span>
      </h1>
      <p className="hero-desc fadeup" style={{ '--d': '0.5s' }}>
        Hand-built gaming and workstation PCs, engineered for raw performance and backed by a 3-year warranty.
      </p>
      <div className="hero-buttons fadeup" style={{ '--d': '0.7s' }}>
        <a href="#contact" className="btn btn-primary" data-magnetic>Build Your PC</a>
        <a href="#builds" className="btn btn-outline" data-magnetic>View Builds</a>
      </div>
      <div className="hero-stats fadeup" style={{ '--d': '0.9s' }}>
        <div className="stat">
          <span className="stat-number"><Count to={500} suffix="+" delay={2500} /></span>
          <span className="stat-label">PCs Built</span>
        </div>
        <div className="stat">
          <span className="stat-number"><Count to={4.9} decimals={1} suffix="/5" delay={2500} /></span>
          <span className="stat-label">Average Rating</span>
        </div>
        <div className="stat">
          <span className="stat-number"><Count to={3} suffix=" Year" delay={2500} /></span>
          <span className="stat-label">Warranty</span>
        </div>
      </div>
    </div>
    <div className="scroll-hint" aria-hidden="true"><i /></div>
  </section>
);

export default Hero;
