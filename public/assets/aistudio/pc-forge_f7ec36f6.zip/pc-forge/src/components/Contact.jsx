// src/components/Contact.jsx
import React, { useState, useEffect } from 'react';
import { contactData } from '../data';

const Contact = ({ selectedBuild }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [budget, setBudget] = useState('Under $1000');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (selectedBuild) {
      setMessage(`I am interested in the ${selectedBuild} build.`);
      setSubmitted(false);
    }
  }, [selectedBuild]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim() || !email.includes('@') || !message.trim()) {
      setError('Please enter your name, a valid email and a message.');
      return;
    }
    setError('');
    setSubmitted(true);
    setName('');
    setEmail('');
    setMessage('');
  };

  return (
    <section id="contact" className="section">
      <div className="container">
        <div className="section-header reveal">
          <span className="section-label">Contact</span>
          <h2 className="section-title">Get in Touch</h2>
          <p className="section-sub">
            Tell us what you need and we will get back to you within 24 hours.
          </p>
        </div>

        <div className="contact-grid">
          <div className="contact-info reveal">
            <div className="info-item">
              <span aria-hidden="true">📧</span>
              <span>{contactData.email}</span>
            </div>
            <div className="info-item">
              <span aria-hidden="true">📞</span>
              <span>{contactData.phone}</span>
            </div>
            <div className="info-item">
              <span aria-hidden="true">📍</span>
              <span>{contactData.address}</span>
            </div>
            <div className="info-item">
              <span aria-hidden="true">🕘</span>
              <span>{contactData.hours || 'Mon-Sat: 9am-6pm'}</span>
            </div>
          </div>

          <div className="reveal">
            {submitted ? (
              <div className="form-success">
                <p>Thank you! We will contact you soon.</p>
                <button
                  type="button"
                  className="btn btn-outline"
                  onClick={() => setSubmitted(false)}
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form className="contact-form" onSubmit={handleSubmit}>
                <div className="form-group">
                  <input
                    type="text"
                    placeholder="Your name"
                    aria-label="Your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <input
                    type="email"
                    placeholder="Your email"
                    aria-label="Your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <select
                    aria-label="Budget range"
                    value={budget}
                    onChange={(e) => setBudget(e.target.value)}
                  >
                    <option value="Under $1000">Under $1000</option>
                    <option value="$1000-$2000">$1000-$2000</option>
                    <option value="$2000-$4000">$2000-$4000</option>
                    <option value="$4000+">$4000+</option>
                  </select>
                </div>
                <div className="form-group">
                  <textarea
                    placeholder="Your message"
                    aria-label="Your message"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                  ></textarea>
                </div>
                {error && <p className="form-error">{error}</p>}
                <button type="submit" className="btn btn-primary">
                  Send Message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
