// src/components/Loader.jsx - boot-up intro
import React, { useState, useEffect } from 'react';

const lines = ['INITIALIZING CORE', 'DETECTING GPU', 'LOADING MEMORY', 'SYSTEM READY'];

const Loader = () => {
  const [pct, setPct] = useState(0);
  const [done, setDone] = useState(false);
  const [gone, setGone] = useState(() => window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  useEffect(() => {
    if (gone) return undefined;
    document.body.style.overflow = 'hidden';
    const t0 = performance.now();
    const dur = 1300;
    let raf;
    const timers = [];
    const tick = (t) => {
      const p = Math.min((t - t0) / dur, 1);
      setPct(Math.round(p * 100));
      if (p < 1) {
        raf = requestAnimationFrame(tick);
      } else {
        timers.push(
          setTimeout(() => {
            setDone(true);
            document.body.style.overflow = '';
          }, 150),
          setTimeout(() => setGone(true), 1100)
        );
      }
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      timers.forEach(clearTimeout);
      document.body.style.overflow = '';
    };
  }, [gone]);

  if (gone) return null;
  const step = Math.min(lines.length - 1, Math.floor(pct / 26));

  return (
    <div className={`loader${done ? ' done' : ''}`} aria-hidden="true">
      <div className="loader-inner">
        <div className="loader-logo grad-text">PC FORGE</div>
        <div className="loader-line">
          &gt; {lines[step]}
          <span className="caret" />
        </div>
        <div className="loader-bar">
          <i style={{ width: `${pct}%` }} />
        </div>
        <div className="loader-pct">{pct}%</div>
      </div>
    </div>
  );
};

export default Loader;
