// src/components/Components.jsx
import React from 'react';
import { componentsData } from '../data';
import SectionHeader from './SectionHeader';

const Components = () => (
  <section id="components" className="section section-alt">
    <div className="container">
      <SectionHeader label="Hardware" title="Premium Components" sub="Every part is hand-picked, tested and covered by warranty." />
      <div className="grid">
        {componentsData.map((c) => (
          <div key={c.id} className="card reveal" data-tilt>
            <div className="card-icon">{c.icon}</div>
            <h3 className="comp-name">{c.name}</h3>
            <p className="comp-desc">{c.desc}</p>
            <span className="comp-price">from ${c.price}</span>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default Components;
