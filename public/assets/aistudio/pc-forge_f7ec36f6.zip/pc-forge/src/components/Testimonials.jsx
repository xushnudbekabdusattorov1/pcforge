// src/components/Testimonials.jsx
import React from 'react';
import { testimonialsData } from '../data';
import SectionHeader from './SectionHeader';

const Testimonials = () => (
  <section id="testimonials" className="section section-alt">
    <div className="container">
      <SectionHeader label="Testimonials" title="Loved by Builders" sub="Real feedback from gamers, creators and professionals." />
      <div className="grid">
        {testimonialsData.map((t) => (
          <div key={t.id} className="card reveal">
            <div className="stars" aria-label={`${t.rating} out of 5 stars`}>{'★'.repeat(t.rating)}</div>
            <p className="quote">“{t.quote}”</p>
            <p className="author">{t.name}</p>
            <p className="author-role">{t.role}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default Testimonials;
