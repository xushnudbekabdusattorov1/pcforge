// src/components/SectionHeader.jsx
import React from 'react';

const SectionHeader = ({ label, title, sub }) => (
  <div className="section-header">
    <span className="section-label reveal">{label}</span>
    <h2 className="section-title rw" aria-label={title}>
      {title.split(' ').map((w, i) => (
        <React.Fragment key={w + i}>
          <span className="word" aria-hidden="true">
            <span style={{ '--i': i }}>{w}</span>
          </span>{' '}
        </React.Fragment>
      ))}
    </h2>
    <p className="section-sub reveal" style={{ animationDelay: '0.25s' }}>{sub}</p>
  </div>
);

export default SectionHeader;
