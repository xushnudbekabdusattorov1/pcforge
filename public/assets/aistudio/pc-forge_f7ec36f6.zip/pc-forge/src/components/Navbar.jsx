// src/components/Navbar.jsx
import React, { useState, useEffect } from 'react';

const links = [
  ['Home', 'home'],
  ['Components', 'components'],
  ['Builds', 'builds'],
  ['Services', 'services'],
  ['Why Us', 'why-us'],
  ['Testimonials', 'testimonials'],
  ['Contact', 'contact'],
];

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState('home');

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 50);
      let current = 'home';
      links.forEach(([, id]) => {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top <= window.innerHeight * 0.35) current = id;
      });
      setActive(current);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className={`navbar${scrolled ? ' scrolled' : ''}`}>
      <a href="#home" className="nav-logo grad-text">PC Forge</a>
      <ul className={`nav-links${open ? ' open' : ''}`}>
        {links.map(([label, id]) => (
          <li key={id}>
            <a
              className={`nav-link${active === id ? ' active' : ''}`}
              href={`#${id}`}
              onClick={() => setOpen(false)}
            >
              {label}
            </a>
          </li>
        ))}
      </ul>
      <a className="btn btn-primary nav-cta" data-magnetic href="#contact">Build Your PC</a>
      <button
        className="hamburger"
        aria-label="Toggle menu"
        aria-expanded={open}
        onClick={() => setOpen(!open)}
      >
        <span />
        <span />
        <span />
      </button>
    </header>
  );
};

export default Navbar;
