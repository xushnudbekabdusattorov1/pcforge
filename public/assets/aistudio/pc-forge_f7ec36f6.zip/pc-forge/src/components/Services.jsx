// src/components/Services.jsx
import React from 'react';
import { servicesData } from '../data';
import SectionHeader from './SectionHeader';

const Services = () => (
  <section id="services" className="section section-alt">
    <div className="container">
      <SectionHeader label="Services" title="Built Around You" sub="From a clean-sheet build to a quick tune-up, we handle it end to end." />
      <div className="grid">
        {servicesData.map((s) => (
          <div key={s.id} className="card reveal" data-tilt>
            <div className="card-icon">{s.icon}</div>
            <h3 className="service-name">{s.name}</h3>
            <p className="service-desc">{s.desc}</p>
            <ul className="service-points">
              {s.points.map((p) => (
                <li key={p}>{p}</li>
              ))}
            </ul>
            <p className="service-price">From ${s.price}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default Services;
