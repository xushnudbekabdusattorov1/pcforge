// src/components/Builds.jsx
import React from 'react';
import { buildsData } from '../data';
import SectionHeader from './SectionHeader';
import Count from './Count';

const specIcons = ['🧠', '🎮', '⚡', '💾'];

const Builds = ({ setSelectedBuild }) => {
  const choose = (name) => {
    if (setSelectedBuild) setSelectedBuild(name);
    const target = document.getElementById('contact');
    if (target) target.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="builds" className="section">
      <div className="container">
        <SectionHeader label="Featured Builds" title="Ready-to-Ship Rigs" sub="Pick a proven configuration or use it as a starting point for your own." />
        <div className="grid">
          {buildsData.map((b) => (
            <div key={b.id} className={`card build-card reveal${b.popular ? ' popular' : ''}`} data-tilt>
              {b.popular && <span className="popular-badge">Most Popular</span>}
              <div className="card-icon">{b.icon}</div>
              <h3 className="build-name">{b.name}</h3>
              <p className="build-price"><Count to={b.price} prefix="$" /></p>
              <ul className="spec-list">
                {b.specs.map((s, i) => (
                  <li key={s}>
                    <span aria-hidden="true">{specIcons[i]}</span> {s}
                  </li>
                ))}
              </ul>
              <button type="button" className="btn btn-primary" data-magnetic onClick={() => choose(b.name)}>
                Choose This Build
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Builds;
