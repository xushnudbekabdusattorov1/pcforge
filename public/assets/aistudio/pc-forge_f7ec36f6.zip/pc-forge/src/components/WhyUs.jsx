// src/components/WhyUs.jsx
import React from 'react';
import { whyUsData } from '../data';
import SectionHeader from './SectionHeader';

const WhyUs = () => (
  <section id="why-us" className="section">
    <div className="container">
      <SectionHeader label="Why Choose Us" title="Performance You Can Trust" sub="Quality parts, careful assembly and support that does not disappear after checkout." />
      <div className="grid">
        {whyUsData.map((w) => (
          <div key={w.id} className="card reveal" data-tilt>
            <div className="card-icon">{w.icon}</div>
            <h3 className="why-title">{w.title}</h3>
            <p className="why-text">{w.text}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default WhyUs;
