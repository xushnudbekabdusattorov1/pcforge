// src/components/Marquee.jsx
import React from 'react';
import { brands } from '../data';

const Marquee = () => (
  <div className="marquee" aria-hidden="true">
    <div className="marquee-track">
      {[...brands, ...brands].map((b, i) => (
        <span key={b + i}>{b}</span>
      ))}
    </div>
  </div>
);

export default Marquee;
