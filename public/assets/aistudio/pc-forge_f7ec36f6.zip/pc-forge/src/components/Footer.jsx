// src/components/Footer.jsx
import React from 'react';

const columns = [
  {
    title: 'Products',
    links: [
      { label: 'Components', href: '#components' },
      { label: 'Builds', href: '#builds' },
      { label: 'Services', href: '#services' },
    ],
  },
  {
    title: 'Company',
    links: [
      { label: 'Why Us', href: '#why-us' },
      { label: 'Testimonials', href: '#testimonials' },
    ],
  },
  {
    title: 'Support',
    links: [
      { label: 'Contact Form', href: '#contact' },
      { label: 'support@pcforge.com', href: 'mailto:support@pcforge.com' },
    ],
  },
];

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-col">
            <h3 className="nav-logo grad-text">PC Forge</h3>
            <p className="footer-text">
              Custom gaming and workstation PCs, hand-built by experts and backed by a 3-year warranty.
            </p>
          </div>
          {columns.map((col) => (
            <div className="footer-col" key={col.title}>
              <h3>{col.title}</h3>
              <ul>
                {col.links.map((link) => (
                  <li key={link.label}>
                    <a href={link.href}>{link.label}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mega reveal" aria-hidden="true">PC FORGE</div>
        <div className="footer-bottom">
          <p>© 2026 PC Forge. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
